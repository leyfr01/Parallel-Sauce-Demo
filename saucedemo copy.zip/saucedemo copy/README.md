Run with mvn test
